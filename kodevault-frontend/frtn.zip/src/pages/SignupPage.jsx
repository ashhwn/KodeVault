import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function SignupPage() {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { signup } = useAuth();
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    try {
      await signup(username, email, password);
      navigate('/dashboard');
    } catch (err) {
      setError(err.response?.data?.message || 'Signup failed');
    }
  }

  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'var(--bg)',
      }}
    >
      <div style={{ width: 340 }}>
        <h2 style={{ textAlign: 'center', marginBottom: 4 }}>KodeVault</h2>
        <p style={{ textAlign: 'center', color: 'var(--text-secondary)', fontSize: 13, marginBottom: 24 }}>
          Create your account
        </p>

        <form onSubmit={handleSubmit} className="card">
          <label style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-secondary)' }}>USERNAME</label>
          <input
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
            style={{ marginTop: 4, marginBottom: 14 }}
          />
          <label style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-secondary)' }}>EMAIL</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            style={{ marginTop: 4, marginBottom: 14 }}
          />
          <label style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-secondary)' }}>PASSWORD</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            style={{ marginTop: 4, marginBottom: 18 }}
          />
          {error && <p className="error-text">{error}</p>}
          <button type="submit" style={{ width: '100%' }}>Sign up</button>
        </form>

        <p style={{ textAlign: 'center', fontSize: 12.5, color: 'var(--text-secondary)', marginTop: 16 }}>
          Already have an account? <Link to="/login">Log in</Link>
        </p>
      </div>
    </div>
  );
}