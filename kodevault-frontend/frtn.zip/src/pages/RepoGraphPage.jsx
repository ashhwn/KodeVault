import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import CommitGraph from '../components/CommitGraph';

export default function RepoGraphPage() {
  const { repoId } = useParams();
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    axios
      .get(`http://localhost:5000/api/commits/${repoId}/graph`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((res) => setData(res.data))
      .catch((err) => setError(err.response?.data?.message || 'Failed to load graph'));
  }, [repoId]);

  if (error) return <div>{error}</div>;
  if (!data) return <div>Loading commit graph…</div>;

  return (
    <div>
      <h2>Commit Graph</h2>
      <CommitGraph data={data} />
    </div>
  );
}
import { useState } from 'react';
import DeployModal from '../components/DeployModal';

// inside the component, add:
const [showDeploy, setShowDeploy] = useState(false);

// in the JSX, add near the top:
<button onClick={() => setShowDeploy(true)}>Deploy</button>
{showDeploy && (
  <DeployModal
    repoId={repoId}
    branchName="main"
    onClose={() => setShowDeploy(false)}
  />
)}