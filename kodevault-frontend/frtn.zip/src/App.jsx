import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import LoginPage from './pages/LoginPage';
import SignupPage from './pages/SignupPage';
import DashboardPage from './pages/DashboardPage';
import RepoGraphPage from './pages/RepoGraphPage';
import RepoDetailPage from './pages/RepoDetailPage';
import PRListPage from './pages/PRListPage';
import PRDetailPage from './pages/PRDetailPage';
import IssuesPage from './pages/IssuesPage';
import CommitPage from './pages/CommitPage';

// inside <Routes>:

// inside <Routes>:

// inside <Routes>:

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/signup" element={<SignupPage />} />
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <DashboardPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/repos/:repoId"
            element={
              <ProtectedRoute>
                <RepoDetailPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/repos/:repoId/graph"
            element={
              <ProtectedRoute>
                <RepoGraphPage />
              </ProtectedRoute>
            }
          />
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
          <Route path="/repos/:repoId/prs" element={<ProtectedRoute><PRListPage /></ProtectedRoute>} />
<Route path="/repos/:repoId/prs/:prId" element={<ProtectedRoute><PRDetailPage /></ProtectedRoute>} />
<Route path="/repos/:repoId/commit" element={<ProtectedRoute><CommitPage /></ProtectedRoute>} />

<Route path="/repos/:repoId/issues" element={<ProtectedRoute><IssuesPage /></ProtectedRoute>} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}