const prisma = require('../config/db');
const { diffCommits } = require('../utils/diff');
const { findCommonAncestor, threeWayMerge } = require('../utils/merge');
const { hashTreeEntries, hashCommit } = require('../utils/hash');

// POST /api/prs/:repoId
// body: { title, description, sourceBranch, targetBranch }
async function createPR(req, res, next) {
  try {
    const { title, description, sourceBranch, targetBranch } = req.body;
    if (!title || !sourceBranch || !targetBranch) {
      return res.status(400).json({ message: 'title, sourceBranch, targetBranch are required' });
    }

    const repoId = req.params.repoId;

    const source = await prisma.branch.findUnique({
      where: { repoId_name: { repoId, name: sourceBranch } },
    });
    const target = await prisma.branch.findUnique({
      where: { repoId_name: { repoId, name: targetBranch } },
    });
    if (!source || !target) {
      return res.status(404).json({ message: 'One or both branches not found' });
    }

    const pr = await prisma.pullRequest.create({
      data: {
        repoId,
        title,
        description: description || '',
        authorId: req.user.id,
        sourceBranch,
        targetBranch,
        sourceCommit: source.headHash,
        targetCommit: target.headHash,
      },
    });

    res.status(201).json(pr);
  } catch (err) {
    next(err);
  }
}

// GET /api/prs/:repoId
async function listPRs(req, res, next) {
  try {
    const prs = await prisma.pullRequest.findMany({
      where: { repoId: req.params.repoId },
      include: { author: { select: { id: true, username: true } } },
      orderBy: { createdAt: 'desc' },
    });
    res.json(prs);
  } catch (err) {
    next(err);
  }
}

// GET /api/prs/item/:prId
async function getPR(req, res, next) {
  try {
    const pr = await prisma.pullRequest.findUnique({
      where: { id: req.params.prId },
      include: {
        author: { select: { id: true, username: true } },
        comments: { include: { author: { select: { id: true, username: true } } } },
      },
    });
    if (!pr) return res.status(404).json({ message: 'PR not found' });
    res.json(pr);
  } catch (err) {
    next(err);
  }
}

// POST /api/prs/item/:prId/comments
async function addComment(req, res, next) {
  try {
    const { text } = req.body;
    if (!text) return res.status(400).json({ message: 'Comment text is required' });

    const comment = await prisma.pRComment.create({
      data: {
        prId: req.params.prId,
        authorId: req.user.id,
        text,
      },
    });

    res.status(201).json(comment);
  } catch (err) {
    next(err);
  }
}

// GET /api/prs/item/:prId/diff
async function getPRDiff(req, res, next) {
  try {
    const pr = await prisma.pullRequest.findUnique({ where: { id: req.params.prId } });
    if (!pr) return res.status(404).json({ message: 'PR not found' });

    const diff = await diffCommits(pr.targetCommit, pr.sourceCommit, pr.repoId);
    res.json(diff);
  } catch (err) {
    if (err.status === 404) return res.status(404).json({ message: err.message });
    next(err);
  }
}

// PATCH /api/prs/item/:prId/sync
// Re-reads current branch heads and refreshes the PR's stored snapshot.
// Needed because sourceCommit/targetCommit are captured once at PR creation —
// if either branch gets new commits afterward, the PR would otherwise merge
// against a stale, outdated snapshot and silently drop those new commits.
async function syncPR(req, res, next) {
  try {
    const pr = await prisma.pullRequest.findUnique({ where: { id: req.params.prId } });
    if (!pr) return res.status(404).json({ message: 'PR not found' });
    if (pr.status !== 'OPEN') {
      return res.status(400).json({ message: `PR is ${pr.status.toLowerCase()}, cannot sync` });
    }

    const [source, target] = await Promise.all([
      prisma.branch.findUnique({ where: { repoId_name: { repoId: pr.repoId, name: pr.sourceBranch } } }),
      prisma.branch.findUnique({ where: { repoId_name: { repoId: pr.repoId, name: pr.targetBranch } } }),
    ]);
    if (!source || !target) {
      return res.status(404).json({ message: 'One or both branches no longer exist' });
    }

    const updated = await prisma.pullRequest.update({
      where: { id: pr.id },
      data: { sourceCommit: source.headHash, targetCommit: target.headHash },
    });

    res.json(updated);
  } catch (err) {
    next(err);
  }
}

async function buildTreeFromHashes(pathMap, tx) {
  const root = {};
  for (const [path, blobHash] of Object.entries(pathMap)) {
    const parts = path.split('/').filter(Boolean);
    let node = root;
    for (let i = 0; i < parts.length - 1; i++) {
      node[parts[i]] = node[parts[i]] || { __dir: true, children: {} };
      node = node[parts[i]].children;
    }
    node[parts[parts.length - 1]] = { __dir: false, hash: blobHash };
  }

  async function processNode(node) {
    const entries = [];
    for (const name of Object.keys(node).sort()) {
      const item = node[name];
      if (item.__dir) {
        const subtreeHash = await processNode(item.children);
        entries.push({ name, type: 'tree', hash: subtreeHash });
      } else {
        entries.push({ name, type: 'blob', hash: item.hash });
      }
    }
    const treeHash = hashTreeEntries(entries);
    await tx.tree.upsert({
      where: { hash: treeHash },
      update: {},
      create: { hash: treeHash, entries },
    });
    return treeHash;
  }

  return processNode(root);
}

// POST /api/prs/item/:prId/merge
// Always merges against the branches' LIVE current heads (not the possibly-
// stale snapshot stored on the PR) — this closes the "stale PR silently
// drops new commits" bug. If clean, creates a 2-parent merge commit and
// closes the PR. If conflicts exist, marks CONFLICT and returns them —
// no partial/silent merges either way.
async function mergePR(req, res, next) {
  try {
    const pr = await prisma.pullRequest.findUnique({ where: { id: req.params.prId } });
    if (!pr) return res.status(404).json({ message: 'PR not found' });
    if (pr.status !== 'OPEN') {
      return res.status(400).json({ message: `PR is already ${pr.status.toLowerCase()}` });
    }

    const [sourceBranch, targetBranch] = await Promise.all([
      prisma.branch.findUnique({ where: { repoId_name: { repoId: pr.repoId, name: pr.sourceBranch } } }),
      prisma.branch.findUnique({ where: { repoId_name: { repoId: pr.repoId, name: pr.targetBranch } } }),
    ]);
    if (!sourceBranch || !targetBranch) {
      return res.status(404).json({ message: 'One or both branches no longer exist' });
    }

    const liveSourceCommit = sourceBranch.headHash;
    const liveTargetCommit = targetBranch.headHash;

    const baseHash = await findCommonAncestor(liveSourceCommit, liveTargetCommit);
    const { merged, conflicts } = await threeWayMerge(baseHash, liveSourceCommit, liveTargetCommit);

    if (conflicts.length > 0) {
      await prisma.pullRequest.update({
        where: { id: pr.id },
        data: { status: 'CONFLICT', sourceCommit: liveSourceCommit, targetCommit: liveTargetCommit },
      });
      return res.status(409).json({
        message: 'Merge conflict — manual resolution required',
        conflicts,
      });
    }

    const result = await prisma.$transaction(async (tx) => {
      const mergedTreeHash = await buildTreeFromHashes(merged, tx);
      const timestamp = Date.now();
      const mergeCommitHash = hashCommit({
        tree: mergedTreeHash,
        parents: [liveTargetCommit, liveSourceCommit],
        message: `Merge pull request: ${pr.title}`,
        authorId: req.user.id,
        timestamp,
      });

      await tx.commit.create({
        data: {
          hash: mergeCommitHash,
          repoId: pr.repoId,
          treeHash: mergedTreeHash,
          message: `Merge pull request: ${pr.title}`,
          authorId: req.user.id,
        },
      });

      await tx.commitParent.createMany({
        data: [
          { childHash: mergeCommitHash, parentHash: liveTargetCommit },
          { childHash: mergeCommitHash, parentHash: liveSourceCommit },
        ],
      });

      await tx.branch.update({
        where: { repoId_name: { repoId: pr.repoId, name: pr.targetBranch } },
        data: { headHash: mergeCommitHash },
      });

      return tx.pullRequest.update({
        where: { id: pr.id },
        data: {
          status: 'MERGED',
          mergeCommit: mergeCommitHash,
          sourceCommit: liveSourceCommit,
          targetCommit: liveTargetCommit,
        },
      });
    });

    res.json(result);
  } catch (err) {
    next(err);
  }
}

// POST /api/prs/item/:prId/resolve
// body: { resolutions: [{ path, blobHash }] }
async function resolveMergeConflict(req, res, next) {
  try {
    const { resolutions } = req.body;
    const pr = await prisma.pullRequest.findUnique({ where: { id: req.params.prId } });
    if (!pr) return res.status(404).json({ message: 'PR not found' });
    if (pr.status !== 'CONFLICT') {
      return res.status(400).json({ message: 'PR is not in a conflict state' });
    }

    const liveSourceCommit = pr.sourceCommit;
    const liveTargetCommit = pr.targetCommit;

    const baseHash = await findCommonAncestor(liveSourceCommit, liveTargetCommit);
    const { merged, conflicts } = await threeWayMerge(baseHash, liveSourceCommit, liveTargetCommit);

    const resolutionMap = new Map(resolutions.map((r) => [r.path, r.blobHash]));
    for (const conflict of conflicts) {
      const chosenHash = resolutionMap.get(conflict.path);
      if (!chosenHash) {
        return res.status(400).json({
          message: `Missing resolution for conflicting file: ${conflict.path}`,
        });
      }
      // validate the chosen hash is a real, existing blob — don't trust
      // client input blindly, since a bogus hash here would corrupt the
      // resulting merge commit's tree with a dangling reference
      const blobExists = await prisma.blob.findUnique({ where: { hash: chosenHash } });
      if (!blobExists) {
        return res.status(400).json({
          message: `Resolution for ${conflict.path} references a blob that doesn't exist`,
        });
      }
      merged[conflict.path] = chosenHash;
    }

    const result = await prisma.$transaction(async (tx) => {
      const mergedTreeHash = await buildTreeFromHashes(merged, tx);
      const timestamp = Date.now();
      const mergeCommitHash = hashCommit({
        tree: mergedTreeHash,
        parents: [liveTargetCommit, liveSourceCommit],
        message: `Merge pull request (manually resolved): ${pr.title}`,
        authorId: req.user.id,
        timestamp,
      });

      await tx.commit.create({
        data: {
          hash: mergeCommitHash,
          repoId: pr.repoId,
          treeHash: mergedTreeHash,
          message: `Merge pull request (manually resolved): ${pr.title}`,
          authorId: req.user.id,
        },
      });

      await tx.commitParent.createMany({
        data: [
          { childHash: mergeCommitHash, parentHash: liveTargetCommit },
          { childHash: mergeCommitHash, parentHash: liveSourceCommit },
        ],
      });

      await tx.branch.update({
        where: { repoId_name: { repoId: pr.repoId, name: pr.targetBranch } },
        data: { headHash: mergeCommitHash },
      });

      return tx.pullRequest.update({
        where: { id: pr.id },
        data: { status: 'MERGED', mergeCommit: mergeCommitHash },
      });
    });

    res.json(result);
  } catch (err) {
    next(err);
  }
}

module.exports = {
  createPR,
  listPRs,
  getPR,
  addComment,
  getPRDiff,
  syncPR,
  mergePR,
  resolveMergeConflict,
};