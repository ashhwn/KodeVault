const express = require('express');
const router = express.Router();
const {
  createRepo,
  getRepo,
  listUserRepos,
  toggleStar,
  addCollaborator,
} = require('../controllers/repoController');
const { protect } = require('../middleware/auth');

router.post('/', protect, createRepo);
router.get('/:id', protect, getRepo);
router.get('/user/:username', protect, listUserRepos);
router.post('/:id/star', protect, toggleStar);
router.post('/:id/collaborators', protect, addCollaborator);
const {
  createRepo,
  getRepo,
  listUserRepos,
  toggleStar,
  addCollaborator,
  forkRepo,
} = require('../controllers/repoController');
// ...
router.post('/:id/fork', protect, forkRepo);
module.exports = router;
const express = require('express');
const router = express.Router();
const {
  createRepo,
  getRepo,
  listUserRepos,
  toggleStar,
  addCollaborator,
  forkRepo,
} = require('../controllers/repoController');
const { protect } = require('../middleware/auth');
const { loadRepoAndAccess, requireRead, requireWrite } = require('../middleware/repoAccess');

router.post('/', protect, createRepo);
router.get('/user/:username', protect, listUserRepos);
router.get('/:id', protect, loadRepoAndAccess, requireRead, getRepo);
router.post('/:id/star', protect, loadRepoAndAccess, requireRead, toggleStar);
router.post('/:id/collaborators', protect, loadRepoAndAccess, requireWrite, addCollaborator);
router.post('/:id/fork', protect, loadRepoAndAccess, requireRead, forkRepo);

module.exports = router;